//
//  LabibaBotFramwork.h
//  LabibaBotFramwork
//
//  Created by Abdul Rahman on 7/16/19.
//  Copyright © 2019 Abdul Rahman. All rights reserved.
//

#import <UIKit/UIKit.h>
// added for socketroket
#import "SRWebSocket.h"

//! Project version number for LabibaBotFramwork.
FOUNDATION_EXPORT double LabibaBotFramworkVersionNumber;

//! Project version string for LabibaBotFramwork.
FOUNDATION_EXPORT const unsigned char LabibaBotFramworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LabibaBotFramwork/PublicHeader.h>


